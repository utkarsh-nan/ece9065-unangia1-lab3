import { Component, OnInit } from '@angular/core';
import { TutorialService } from 'src/app/services/tutorial.service';

@Component({
  selector: 'app-add-tutorial',
  templateUrl: './add-tutorial.component.html',
  styleUrls: ['./add-tutorial.component.css']
})
export class AddTutorialComponent implements OnInit {
  tutorial = {
    title: '',
    description: '',
    description2: '',
    description3: '',
    description4: '',
    description5: '',
    description6: '',
    description7: '',
    description8: '',
    description9: '',
    descriptionk: '',  };
  submitted = false;

  constructor(private tutorialService: TutorialService) { }

  ngOnInit(): void {
  }

  saveTutorial(): void {
    const data = {
      title: this.tutorial.title,
      description: this.tutorial.description,
      description2: this.tutorial.description2,
      description3: this.tutorial.description3,
      description4: this.tutorial.description4,
      description5: this.tutorial.description5,
      description6: this.tutorial.description6,
      description7: this.tutorial.description7,
      description8: this.tutorial.description8,
      description9: this.tutorial.description9,
      descriptionk: this.tutorial.descriptionk,    };

    this.tutorialService.create(data)
      .subscribe(
        response => {
          console.log(response);
          this.submitted = true;
        },
        error => {
          console.log(error);
        });
  }

  newTutorial(): void {
    this.submitted = false;
    this.tutorial = {
    title: '',
    description: '',
    description2: '',
    description3: '',
    description4: '',
    description5: '',
    description6: '',
    description7: '',
    description8: '',
    description9: '',
    descriptionk: '',  };
  }

}
