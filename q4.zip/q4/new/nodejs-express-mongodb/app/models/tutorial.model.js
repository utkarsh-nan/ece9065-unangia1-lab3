module.exports = mongoose => {
  var schema = mongoose.Schema(
    {
      title: String,
      description: String,
      description2: String,
      description3: String,
      description4: String,
      description5: String,
      description6: String,
      description7: String,
      description8: String,
      description9: String,
      descriptionk: String,
    },
  );

  schema.method("toJSON", function() {
    const { __v, _id, ...object } = this.toObject();
    object.id = _id;
    return object;
  });

  const Tutorial = mongoose.model("tutorial", schema);
  return Tutorial;
};
