module.exports = {
  url: "mongodb://localhost:27017/bezkoder_db"
};
